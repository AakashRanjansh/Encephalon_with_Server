# CNNCalc

### Review 2 Demo Coding....

#### Major Project

## Support

For support, email sahaakashranjan@proton.me

## Authors

- [@Aakash Ranjan Sah](https://github.com/AakashRanjansh)
